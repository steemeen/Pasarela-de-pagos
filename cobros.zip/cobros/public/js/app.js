import { auth, db } from "./firebase-init.js";
import {
signInWithEmailAndPassword,
createUserWithEmailAndPassword,
onAuthStateChanged,
signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
collection,
addDoc,
getDocs,
query,
where,
doc,
updateDoc,
deleteDoc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

let currentUserId = null;

function mostrarElemento(id) {
document.getElementById("login-container").style.display = "none";
document.getElementById("registro-container").style.display = "none";
document.getElementById("app-container").style.display = "none";
document.getElementById(id).style.display = "block";
}

onAuthStateChanged(auth, (user) => {
if (user) {
    currentUserId = user.uid;
    mostrarElemento("app-container");
    cargarPrestamos();
} else {
    mostrarElemento("login-container");
}
});


const loginForm = document.getElementById("login-form");
loginForm.addEventListener("submit", async (e) => {
e.preventDefault();
const email = document.getElementById("usuario").value;
const password = document.getElementById("contrasena").value;
try {
    await signInWithEmailAndPassword(auth, email, password);
    
    mostrarElemento("app-container"); 
    console.log("Inicio de sesión exitoso");
} catch (err) {
    alert("Error al iniciar sesión: " + err.message);
}
});

document.getElementById("mostrar-registro").addEventListener("click", () => {
mostrarElemento("registro-container");
});

document.getElementById("mostrar-login").addEventListener("click", () => {
mostrarElemento("login-container");
});



const registroForm = document.getElementById("registro-form");
registroForm.addEventListener("submit", async (e) => {
e.preventDefault();
const email = document.getElementById("registro-usuario").value;
const password = document.getElementById("registro-contrasena").value;
try {
    await createUserWithEmailAndPassword(auth, email, password);
} catch (err) {
    alert("Error al registrar: " + err.message);
}
});


document.getElementById("cerrar-sesion").addEventListener("click", async () => {
await signOut(auth);
});


function sumarPeriodos(fechaInicio, frecuencia, cantidad) {
const fecha = new Date(fechaInicio);
if (frecuencia === "mensual") fecha.setMonth(fecha.getMonth() + cantidad);
  else if (frecuencia === "quincenal") fecha.setDate(fecha.getDate() + 15 * cantidad);
  else if (frecuencia === "semanal") fecha.setDate(fecha.getDate() + 7 * cantidad);
return fecha.toISOString().split("T")[0];
}

function formatoMiles(numero) {
return Number(numero).toLocaleString("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});
}


document.getElementById("form-prestamo").addEventListener("submit", async (e) => {
e.preventDefault();
const nombre = document.getElementById("nombre").value.trim();
const monto = parseFloat(document.getElementById("monto").value);
const interes = parseFloat(document.getElementById("interes").value);
const fechaInicio = document.getElementById("fechaInicio").value;
const cuotas = parseInt(document.getElementById("cuotas").value);
const frecuencia = document.getElementById("frecuencia").value;

if (!nombre || isNaN(monto) || isNaN(interes) || !fechaInicio || isNaN(cuotas) || !frecuencia) {
    alert("Por favor, complete todos los campos correctamente.");
    return;
}

const fechaVencimiento = sumarPeriodos(fechaInicio, frecuencia, cuotas - 1);

try {
    await addDoc(collection(db, "prestamos"), {
    userId: currentUserId,
    nombre,
    monto,
    interes,
    fechaInicio,
    cuotas,
    frecuencia,
    fechaVencimiento,
    abonos: []
    });
    document.getElementById("form-prestamo").reset();
    cargarPrestamos();
} catch (err) {
    alert("Error al guardar el préstamo: " + err.message);
}
});


async function cargarPrestamos() {
const contenedor = document.getElementById("lista-prestamos");
contenedor.innerHTML = "";

const q = query(collection(db, "prestamos"), where("userId", "==", currentUserId));
const snapshot = await getDocs(q);

snapshot.forEach(docSnap => {
    const p = docSnap.data();
    const id = docSnap.id;

    const totalInteres = p.monto * (p.interes / 100);
    const totalDeuda = p.monto + totalInteres;
    const valorCuota = totalDeuda / p.cuotas;
    const totalAbonado = p.abonos.reduce((sum, ab) => sum + ab, 0);
    const saldoPendiente = totalDeuda - totalAbonado;

    const card = document.createElement("div");
    card.classList.add("col");
    card.innerHTML = `
    <div class="prestamo">
        <h5>${p.nombre}</h5>
        <p>Monto: $${formatoMiles(p.monto)}<br>
        Interés: ${p.interes}%<br>
        Cuotas: ${p.cuotas}<br>
        Frecuencia: ${p.frecuencia}<br>
        Fecha inicio: ${p.fechaInicio}<br>
        Fecha vencimiento: ${p.fechaVencimiento}<br>
        Valor cuota: $${formatoMiles(valorCuota)}<br>
        Total abonado: $${formatoMiles(totalAbonado)}<br>
        Saldo pendiente: $${formatoMiles(saldoPendiente)}</p>

        <div class="abono-section">
        <input type="number" min="1" step="0.01" id="abono-${id}" placeholder="Valor del abono" />
        <button class="btn btn-success mt-1" onclick="agregarAbono('${id}', ${valorCuota})">Registrar abono</button>
        </div>

        <button class="btn btn-danger mt-2" onclick="eliminarPrestamo('${id}')">Eliminar préstamo</button>
    </div>`;

    contenedor.appendChild(card);
});
}

window.agregarAbono = async (id, valorCuota) => {
const input = document.getElementById(`abono-${id}`);
const valor = parseFloat(input.value);
if (isNaN(valor) || valor <= 0) {
    alert("Ingrese un valor válido para el abono.");
    return;
}
const docRef = doc(db, "prestamos", id);
const prestamoSnap = await getDocs(query(collection(db, "prestamos"), where("userId", "==", currentUserId)));

for (const d of prestamoSnap.docs) {
    if (d.id === id) {
    const datos = d.data();
    const nuevosAbonos = [...datos.abonos, valor];
      const totalInteres = datos.monto * (datos.interes / 100);
    const totalDeuda = datos.monto + totalInteres;
    const totalAbonado = nuevosAbonos.reduce((s, a) => s + a, 0);

    if (totalAbonado >= totalDeuda) {
        await deleteDoc(docRef);
    } else {
        await updateDoc(docRef, { abonos: nuevosAbonos });
    }
    break;
    }
}
cargarPrestamos();
};


window.eliminarPrestamo = async (id) => {
if (!confirm("¿Está seguro que desea eliminar este préstamo?")) return;
await deleteDoc(doc(db, "prestamos", id));
cargarPrestamos();
};
