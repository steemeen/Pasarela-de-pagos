import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
apiKey: "AIzaSyCsE62wwGqqVsTUcvuZaSfKqnAV5vrwqG0",
authDomain: "app-de-cobros-7c9cb.firebaseapp.com",
projectId: "app-de-cobros-7c9cb",
storageBucket: "app-de-cobros-7c9cb.appspot.com",
messagingSenderId: "56720987095",
appId: "1:56720987095:web:0d8ad0d85c9a294f5f3192",
measurementId: "G-2KJGXGJ4RM"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };
